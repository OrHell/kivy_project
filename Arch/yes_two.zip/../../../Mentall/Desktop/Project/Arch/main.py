import zipfile##Импорт архивации
from kivy.app import App##Импорт киви
from kivy.uix.button import Button##импорт кнопачек
from kivy.config import Config##Импорт изменения окошка
from kivy.uix.floatlayout import FloatLayout

Config.set('graphics','resizeble','0');##Изминения чтобы окошко не двигалось
Config.set('graphics','width','640');##Изминения ширина
Config.set('graphics','height','480');##Изминение высоты

class MyApp(App):##Основной класс
	def build (self):##Создание кнопочки которая архивирует
		fl = FloatLayout(size =(300,300))
		fl.add_widget(Button(text="Zip",on_press = self.btn_press,size_hint = (.5,.25),pos = (0,0)))##Кнопочка что начинает архивировать
		return fl
		

	def btn_press(self, instance):##Сам класс архивации
		instance = jungle_zip = zipfile.ZipFile('C:\\Users\\Гусев\\Desktop\\Project\\yes.zip', 'w')
		jungle_zip.write('C:\\Users\\Гусев\\Desktop\\Project\\kim.jpg', compress_type=zipfile.ZIP_DEFLATED)
		jungle_zip.close()##Конец
		pass##Конец кнопочки
class MyApp(App):	
	def build(self):##Вторая кнопочка для разархивирования
		return Button(text = "Unziup",on_press = self.btn1_press)##При нажатии переходит на разархивацию
	
	def btn1_press(self, instance):##Сам этот класс разорхивации
		instance = fantasy_zip = zipfile.ZipFile('C:\\Users\\Гусев\\Desktop\\Project\\yes.zip')
		fantasy_zip.extract('kim.jpg','C:\\Users\\Гусев\\Desktop\\Project\\zip\\')
 		fantasy_zip.close()
 		pass 




if __name__ == "__main__":##
	 MyApp().run()##
